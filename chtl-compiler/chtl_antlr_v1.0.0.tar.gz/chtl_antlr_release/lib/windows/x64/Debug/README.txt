CHTL ANTLR Libraries - Windows x64 Debug

This directory should contain:
- chtl_css_d.lib (~8MB)
- chtl_javascript_d.lib (~12MB)
- antlr4-runtime_d.lib (~20MB)
- chtl_antlr_all_d.lib (~40MB)

These files are built using:
- Visual Studio 2022 (MSVC v143)
- C++17 standard
- /MDd runtime (Multi-threaded DLL Debug)
- /Od (No optimization)
- Debug symbols included

Debug libraries have '_d' suffix to distinguish from release versions.