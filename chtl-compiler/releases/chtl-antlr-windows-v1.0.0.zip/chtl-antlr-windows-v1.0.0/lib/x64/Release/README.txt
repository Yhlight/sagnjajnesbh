CHTL ANTLR Libraries - Windows x64 Release

This directory should contain:
- chtl_css.lib (~2MB)
- chtl_javascript.lib (~3MB)  
- antlr4-runtime.lib (~5MB)
- chtl_antlr_all.lib (~10MB)

These files are built using:
- Visual Studio 2022 (MSVC v143)
- C++17 standard
- /MD runtime (Multi-threaded DLL)
- /O2 optimization

To obtain these files:
1. Run build_all_windows.bat on a Windows machine
2. Or download from GitHub releases
3. Or use the GitHub Actions artifacts